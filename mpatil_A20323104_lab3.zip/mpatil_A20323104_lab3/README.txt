Attached are two versions of the same file: 
mpatil_A20323104_lab3.html conatins the code WITH animation that I was able to get going. (It is NOT a completely functional code)
mpatil_A20323104_lab3-no-animation.html contains code WITH NO animation.

I emailed the professor and he advised me to submit a copy where I have attempted to animate the objects, without disrupting other elements
in the file. 
Here is my logic:
1) Draw static objects.
2) Save context, translate, rotate and draw the object (square)
3) Restore context.
4) Because there were two animated objects here, I repeated (2) and (3) again (for the arc).
5) Restore again.

